import java.util.NoSuchElementException;
import java.lang.OutOfMemoryError;

/**
 * Queue that is backed with a simple object array.
 * @author benleong
 */
public class ArrayQueue implements Queue {

    /**
     * Test code
     * @param args
     */
    public static void main(String[] args) {
        ArrayQueue q = new ArrayQueue(5);
        for (int i=0; i<5; i++) {
            q.enqueue(i);
        }
        for (int i=0; i<5; i++) {
            if (i==2) {
                System.out.println(q.peek());
            }
            System.out.println(q.dequeue());
        }
    }
    
}
